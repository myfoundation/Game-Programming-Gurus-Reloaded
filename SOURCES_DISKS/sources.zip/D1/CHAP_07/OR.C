
#include <stdio.h>


char far *source, *dest;  // the source and destination data regions

void main(void)
{

int index;
unsigned data;

// logical operator version (OR)

dest[index]=dest[index]=data | source[index];

} // end main
