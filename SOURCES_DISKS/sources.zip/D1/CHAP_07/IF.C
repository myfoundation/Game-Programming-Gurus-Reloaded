
#include <stdio.h>


char far *source, *dest;  // the source and destination data regions

void main(void)
{

int index;
unsigned data;

// if version

if (data=source[index])
   dest[index]=data;

} // end main
