// DrawPoly.h
// Guy Simmons, 1st November 1996.

#ifndef	_DRAWPOLY_H_
#define	_DRAWPOLY_H_


#endif
