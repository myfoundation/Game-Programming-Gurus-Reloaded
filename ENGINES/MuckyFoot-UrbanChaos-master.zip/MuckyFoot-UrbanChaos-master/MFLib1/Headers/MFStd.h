// MFStd.h
// Guy Simmons, 17th October 1996.

#ifndef	_MFSTD_H_
#define	_MFSTD_H_

#ifndef	_MF_TYPES_H_
	#include	<MFTypes.h>
#endif

#ifndef	_MF_ERRORS_H_
	#include	<MFErrors.h>
#endif


#endif