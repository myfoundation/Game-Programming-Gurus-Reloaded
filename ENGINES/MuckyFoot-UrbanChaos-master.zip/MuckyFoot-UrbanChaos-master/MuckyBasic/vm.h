//
// The virtual machine to run our basic programs.
//

#ifndef _VM_
#define _VM_


//
// Loads the given MuckyBASIC program into memory and runs it!
//

void VM_run(CBYTE *fname);



#endif
