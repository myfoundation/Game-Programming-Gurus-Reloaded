//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by muckyBASIC.rc
//
#define IDD_DRIVERS                     101
#define IDI_ICON1                       103
#define IDR_MAIN_MENU                   106
#define IDR_POPUPS                      110
#define IDC_COMBO1                      1000
#define IDC_COMBO_DRIVER                1000
#define IDC_COMBO2                      1001
#define IDC_COMBO_MODE                  1001
#define IDC_BUTTON1                     1002
#define IDC_MINFRAMERATE                1006
#define IDC_CONSTRES                    1018
#define IDC_PROCESSOR                   1022
#define IDC_RUN_DRIVING_GAME            1030
#define IDC_RUN_MY_GAME                 1031
#define IDC_RUN_MIKES_GAME              1032
#define IDC_RUN_LIQUID_METAL            1033
#define IDC_RUN_ANIMATION_TEST          1034
#define IDC_RUN_TOON_TEST               1064
#define IDC_RUN_EGG_PHYSICS             1065
#define IDC_RUN_PATCH_TEST              1066
#define ID_MODE_BRUSH                   40003
#define ID_BRUSH_TREE                   40005
#define ID_MODE_SELECT                  40009
#define ID_CAMERA_FOLLOWCAR             40010
#define ID_CAMERA_LOCKEDAROUNDPOINT     40011
#define ID_CAMERA_RESET                 40013
#define ID_BRUSH_GRASS                  40014
#define ID_BRUSH_OB                     40015
#define ID_FILE_RESET                   40016
#define ID_FILE_OPENMAP                 40017
#define ID_FILE_SAVEMAP                 40018
#define ID_FILE_SAVEMAPAS               40019
#define ID_FILE_LOADTRACKMESH           40020
#define ID_BRUSH_CAR                    40024
#define ID_EDIT_DELETE                  40027
#define ID_CAMERA_1STPERSON             40028
#define ID_CAMERA_DIFFERENTCAR          40030
#define ID_DRAW_TRACK                   40031
#define ID_DRAW_OBS                     40032
#define ID_DRAW_LINES                   40033
#define ID_DRAW_CARS                    40034
#define ID_CAR_MOVETO_POLEPOSITION      40044
#define ID_CAR_MOVETO_2NDPLACE          40046
#define ID_CAR_MOVETO_3RDPLACE          40047
#define ID_CAR_MOVETO_4THPLACE          40048
#define ID_CAR_MOVETO_5THPLACE          40049
#define ID_CAR_MOVETO_6THPLACE          40050
#define ID_SPLINE_STARTINGLINE          40051
#define ID_SPLINE_TRACKSEGMENT_1        40053
#define ID_SPLINE_TRACKSEGMENT_2        40054
#define ID_SPLINE_TRACKSEGMENT_3        40055
#define ID_SPLINE_TRACKSEGMENT_4        40056
#define ID_SPLINE_TRACKSEGMENT_5        40057
#define ID_SPLINE_TRACKSEGMENT_6        40058
#define ID_SPLINE_TRACKSEGMENT_7        40059
#define ID_SPLINE_TRACKSEGMENT_8        40060
#define ID_SPLINE_TRACKSEGMENT_9        40061
#define ID_SPLINE_TRACKSEGMENT_10       40062
#define ID_SPLINE_TRACKSEGMENT_11       40063
#define ID_SPLINE_TRACKSEGMENT_12       40064
#define ID_SPLINE_TRACKSEGMENT_13       40065
#define ID_SPLINE_TRACKSEGMENT_14       40066
#define ID_SPLINE_TRACKSEGMENT_15       40067
#define ID_SPLINE_TRACKSEGMENT_16       40068
#define ID_CAR_DEF_POLEPOSITION         40069
#define ID_CAR_DEF_2NDPLACE             40070
#define ID_CAR_DEF_3RDPLACE             40071
#define ID_CAR_DEF_4THPLACE             40072
#define ID_CAR_DEF_5THPLACE             40073
#define ID_CAR_DEF_6THPLACE             40074

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40075
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
