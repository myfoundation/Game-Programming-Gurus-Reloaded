//
// The compiler.
//

#ifndef _COMP_
#define _COMP_



//
// Compiles the input file to produce the output file.
//

SLONG COMP_do(CBYTE *fname_input, CBYTE *fname_output);



#endif
