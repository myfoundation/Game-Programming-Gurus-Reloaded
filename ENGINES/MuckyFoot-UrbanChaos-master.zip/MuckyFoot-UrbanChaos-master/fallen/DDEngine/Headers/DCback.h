//
// The background...
//

#ifndef _BACK_
#define _BACK_



//
// Loads the textures.
//

void BACK_init(void);


//
// Draws the background polys- it clears both the screen and
// the z-buffer.
//

void BACK_draw(void);



#endif
