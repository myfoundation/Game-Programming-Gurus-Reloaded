//
// Draws the credits
//

#ifndef _CREDITS_
#define _CREDITS_

//
// Do the credits...
//

void CREDITS_do(void);

#endif
