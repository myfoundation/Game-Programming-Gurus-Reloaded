//
// Realtime raytracing on the PC!
//

#ifndef _RAY_
#define _RAY_



//
// Loops the raytracing demo...
//

void RAY_do(void);



#endif

