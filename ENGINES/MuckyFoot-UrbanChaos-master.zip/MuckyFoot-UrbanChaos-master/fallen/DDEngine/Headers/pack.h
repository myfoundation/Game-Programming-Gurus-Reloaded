//
// Looks at all the textures loaded and packs similar ones
// onto 256x256s...
//

#ifndef _PACK_
#define _PACK_


//
// Does the packing...
//

void PACK_do(void);


#endif
