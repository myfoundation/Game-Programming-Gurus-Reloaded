// polypoint.cpp
//
// PolyPoint class, encapsulating a D3DTLVERTEX

#include <MFStdLib.h>
#include <DDLib.h>
#include <math.h>
#include "poly.h"
#include "vertexbuffer.h"

#include "polypoint.h"

