// KFDef.c
// Guy Simmons, 24th March 1997.


//---------------------------------------------------------------
/*
ControlDef	kframe_def[]	=	
{
	{	BUTTON,			0,	"Load Keyframe Chunk",	2,	CONTROLS_HEIGHT-(20+KEY_FRAME_IMAGE_SIZE+20),	0,						10			},
	{	H_SLIDER,		0,	"",						2,	CONTROLS_HEIGHT-20,								6*KEY_FRAME_IMAGE_SIZE,	0			},
	{	BUTTON,			0,	"New Character",		2,	4,		0,		0			},
	{	V_SLIDER,		0,	"",						104,20,		0,		200			},
	{	EDIT_TEXT,		0,	"",						2,	230,	70,		0			},
	{	STATIC_TEXT,	0,	"Current Prim : ",		2,	246,	0,		0			},
	{	PULLDOWN_MENU,	0,	"Multi Prim",			2,	262,	70,		0,	0		},

	{	0															   				}
};

//---------------------------------------------------------------

ControlDef	content_def[]	=
{
	{	H_SLIDER,		0,	"",						0,	CONTROLS_HEIGHT-16,	6*KEY_FRAME_IMAGE_SIZE,	0			},
	{	STATIC_TEXT,	0,	"FPS",					2,	CONTROLS_HEIGHT-(16+KEY_FRAME_IMAGE_SIZE+16),	0,		10		  	},
	{	H_SLIDER,		0,	"",						22,	CONTROLS_HEIGHT-(16+KEY_FRAME_IMAGE_SIZE+18),	100,	0			},
	{	BUTTON,			0,	"New Anim",				2,	4,		0,		0			},
	{	V_SLIDER,		0,	"",						104,20,		0,		200			},
	{	EDIT_TEXT,		0,	"",						2,	230,	70,		0			},
	{	CHECK_BOX,		KB_L,	"Looped",			2,	246,	70,		0			},
	{	BUTTON,			0,	"Lo-res test",			2,	260,	70,		0			},
	{	BUTTON,			0,	"Save Anims",			2,	276,	70,		0			},

	{	0																			}
};
*/
//---------------------------------------------------------------

MenuDef2	anim_popup[]	=
{
	{"Cut"},{"Copy"},{"Paste"},{"Toggle Unused"},{"!"}
};

//---------------------------------------------------------------
