// Control.cpp
// Guy Simmons, 26th March 1997.

#include	"Editor.hpp"


//---------------------------------------------------------------

void	handle_character_controls(void)
{
	
}

//---------------------------------------------------------------
   