// Editor.h
// Guy Simmons, 18th October 1997.

#ifndef	EDITOR_H
#define	EDITOR_H

//---------------------------------------------------------------

UBYTE	editor(void);

//---------------------------------------------------------------

#endif

