// convert.h
// Mike Diskett, 3rd March 1997.

#ifndef	_CONVERT_H_
#define	_CONVERT_H_

#endif
