#ifndef	GAME_H
#define	GAME_H			1
#include	"macros.h"
#include	"c:\fallen\headers\inline.h"
// turn off "integral value may be truncated" C++ warnings
#ifndef	_MSC_VER	
#pragma	warning	389	9 
#pragma	warning	14 9
#endif
#endif
