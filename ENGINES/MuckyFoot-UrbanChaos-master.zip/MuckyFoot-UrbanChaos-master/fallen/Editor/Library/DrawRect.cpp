// DrawRect.cpp
// Guy Simmons, 11th February 1997.


#include	"Editor.hpp"


//---------------------------------------------------------------

void	DrawRect(MFRect *the_rect,ULONG colour)
{
	the_rect	=	the_rect;
	colour		=	colour;
}

//---------------------------------------------------------------

void	DrawRectC(MFRect *the_rect,ULONG colour)
{
	the_rect	=	the_rect;
	colour		=	colour;
}

//---------------------------------------------------------------
