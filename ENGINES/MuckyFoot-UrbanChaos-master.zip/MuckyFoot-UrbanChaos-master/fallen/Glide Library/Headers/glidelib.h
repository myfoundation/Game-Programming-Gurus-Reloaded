//
// The glide library.
//

#ifndef _GLIDELIB_
#define _GLIDELIB_


//
// I want to cry.
//



#endif
