// stdafx.h
//
// standard crap

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// windows
#include <windows.h>
#include <shellapi.h>

// C stuff
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <stdio.h>

// NLS stuff
#include <winnls.h>

// resources
#include "resource.h"
