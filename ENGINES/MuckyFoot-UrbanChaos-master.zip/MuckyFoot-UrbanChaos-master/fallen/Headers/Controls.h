// Controls.h
// Guy Simmons, 4th November 1997.

#ifndef	CONTROLS_H
#define	CONTROLS_H

//---------------------------------------------------------------

void	process_controls(void);

//---------------------------------------------------------------

#endif
