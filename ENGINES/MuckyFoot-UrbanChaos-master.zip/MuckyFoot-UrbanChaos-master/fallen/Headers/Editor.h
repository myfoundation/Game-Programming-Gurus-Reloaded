// Editor.h
// Guy Simmons, 19th October 1997

#ifndef	EDITOR_H
#define	EDITOR_H

UBYTE	editor_loop(void);

#endif
