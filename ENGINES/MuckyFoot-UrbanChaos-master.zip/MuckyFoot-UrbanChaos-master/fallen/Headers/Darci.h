// Darci.h
// Guy Simmons, 4th January 1998.

#ifndef	DARCI_H
#define	DARCI_H

//---------------------------------------------------------------

extern	StateFunction	darci_states[];

void	fn_darci_init(Thing *t_thing);
void	fn_darci_normal(Thing *t_thing);

//---------------------------------------------------------------

#endif
