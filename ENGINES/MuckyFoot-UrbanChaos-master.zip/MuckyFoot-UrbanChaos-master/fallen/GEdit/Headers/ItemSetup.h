//	ItemSetup.h
//	Guy Simmons, 24th August 1998.

#ifndef	ITEMSETUP_H
#define	ITEMSETUP_H

//---------------------------------------------------------------

void	do_item_setup(EventPoint *the_ep);
CBYTE	*get_item_message(EventPoint *ep, CBYTE *msg);


//---------------------------------------------------------------

#endif
