//	CameraSetup.h
//	Matthew Rosenfeld, 13th October 1998.

#ifndef	_ACTIVATESETUP_H_
#define	_ACTIVATESETUP_H_

#include	"Mission.h"


//---------------------------------------------------------------

void	do_activate_setup(EventPoint *ep);
CBYTE	*get_activate_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
