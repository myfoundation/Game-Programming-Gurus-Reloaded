//	PlayerSetup.h
//	Guy Simmons, 23rd August 1998.

#ifndef	PLAYERSETUP_H
#define	PLAYERSETUP_H

#include	"Mission.h"


//---------------------------------------------------------------

void	do_player_setup(EventPoint *ep);
CBYTE	*get_player_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
