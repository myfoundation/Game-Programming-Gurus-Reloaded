//	CameraSetup.h
//	Matthew Rosenfeld, 30th September 1998.

#ifndef	_CAMERASETUP_H_
#define	_CAMERASETUP_H_

#include	"Mission.h"


//---------------------------------------------------------------

void	do_camera_setup(EventPoint *ep);
CBYTE	*get_camera_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
