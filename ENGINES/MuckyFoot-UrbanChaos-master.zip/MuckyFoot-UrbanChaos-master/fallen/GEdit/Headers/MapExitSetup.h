//	MapExitSetup.h
//	Matthew Rosenfeld, 7th October 1998.

#ifndef	_MAPEXITSETUP_H_
#define	_MAPEXITSETUP_H_

#include	"Mission.h"


//---------------------------------------------------------------

void	do_mapexit_setup(EventPoint *ep);
CBYTE	*get_mapexit_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
