//	CameraSetup.h
//	Matthew Rosenfeld, 1st October 1998.

#ifndef	_CAMTARGETSETUP_H_
#define	_CAMTARGETSETUP_H_

#include	"Mission.h"


//---------------------------------------------------------------

void	do_camtarget_setup(EventPoint *ep);
CBYTE	*get_camtarget_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
