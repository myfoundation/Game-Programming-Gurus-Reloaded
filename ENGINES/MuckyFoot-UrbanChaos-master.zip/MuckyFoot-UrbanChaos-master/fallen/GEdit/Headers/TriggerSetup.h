//	TriggerSetup.h
//	Guy Simmons, 27th August 1998.

#ifndef	TRIGGERSETUP_H
#define	TRIGGERSETUP_H

//---------------------------------------------------------------

void	do_trigger_setup(EventPoint *the_ep);
CBYTE	*get_trigger_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
