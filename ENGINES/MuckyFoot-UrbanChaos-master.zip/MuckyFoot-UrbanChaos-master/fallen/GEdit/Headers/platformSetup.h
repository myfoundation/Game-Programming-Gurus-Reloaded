//	PlatformSetup.h
//	Matthew Rosenfeld, 10th November 1998.

#ifndef	_PLATFORMSETUP_H_
#define	_PLATFORMSETUP_H_

#include	"Mission.h"


//---------------------------------------------------------------

void	do_platform_setup(EventPoint *ep);
//CBYTE	*get_platform_message(EventPoint *ep, CBYTE *msg);

//---------------------------------------------------------------

#endif
