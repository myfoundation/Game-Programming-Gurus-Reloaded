//	WayWind.h
//	Guy Simmons, 31st July 1998.


#ifndef	WAYWIND_H
#define	WAYWIND_H

//---------------------------------------------------------------

BOOL	init_wwind(void);
void	fini_wwind(void);

#define	WAY_COLOURS 15

//---------------------------------------------------------------

#endif
