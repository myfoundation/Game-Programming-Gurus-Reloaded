//
// blah blah inputbox blah
//
// it's just useful
//

#ifndef _INPUT_BOX_H_
#define _INPUT_BOX_H_

#include "MFStdLib.h"

CBYTE *InputBox(CBYTE *title, CBYTE *prompt, CBYTE *txt);

#endif