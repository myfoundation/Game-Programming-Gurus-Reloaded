https://github.com/lowfatcode/another-world

# another-world
An implementation of the game engine from Another World (Out Of This World)
